﻿VirtualKeyboard.addLayout({code:'UG',name:'Uighur Latin',normal:'ä1234567890-öüqwErtyuiop[]asDfghjkl;\'zxCvbnm,./',shift:{1:'!@#$%^&*()_',24:'{}',35:':"',44:'<>?'}});
