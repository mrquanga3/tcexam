﻿VirtualKeyboard.addLayout({code:'TL',name:'Tagalog - Tausug',normal:'ñ1234567890-=ãqwertyuiop[]asdfghjkl;\'zxcvbnm,./',shift:{1:'!@#$%^&*()_+',24:'{}',35:':"',44:'<>?'}});
