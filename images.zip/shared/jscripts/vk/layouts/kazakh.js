﻿VirtualKeyboard.addLayout({code:'KK-KZ',name:'Kazakh',normal:'("әіңғ,.үұқөһ\\йцукенгшщзхъфывапролджэячсмитьбю№',shift:{0:')!',6:';:',13:'/',46:'?'}});
