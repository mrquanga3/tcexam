﻿VirtualKeyboard.addLayout({code:'UK-UA',name:'Ukrainian Translit',normal:'ё1234567890-ґєяшертiуиопющасдфгчйкльжзхцвбнмї.=',shift:{1:'!"№;%:?*()_',45:',+'}});
