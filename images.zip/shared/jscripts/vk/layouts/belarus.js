﻿VirtualKeyboard.addLayout({code:'BE-BY',name:'Belarusian',normal:'ё1234567890-=\\йцукенгшўзх\'фывапролджэячсмітьбю.',shift:{1:'!"№;%:?*()_+/',46:','}});
