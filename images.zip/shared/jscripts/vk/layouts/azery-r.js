﻿VirtualKeyboard.addLayout({code:'AZ',name:'Azeri Cyrillic',normal:'`1234567890-=\\јүукенгшһзхҹфывапролджҝәчсмитғбө.',shift:{0:'~!"№;%:?*()_+/',46:','}});
