﻿VirtualKeyboard.addLayout({code:'KU',name:'Kurdish Latin',normal:'`æîûçéêíşùú-=\\qwertyuiop[]asdfghjkl;\'zxcvbnm,./',shift:{0:'~',11:'_+|',24:'{}',35:':"',44:'<>?'}});
