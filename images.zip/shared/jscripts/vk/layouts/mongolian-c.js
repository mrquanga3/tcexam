﻿VirtualKeyboard.addLayout({code:'MN',name:'Mongolian Cyrillic',normal:'=№-"₮:._,%?ещ\\фцужэнгшүзкъйыбөахролдпячёсмитьвю',shift:{0:'+1234567890',13:'|'}});
