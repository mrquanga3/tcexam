﻿VirtualKeyboard.addLayout({code:'AZ',name:'Azeri Latin',normal:'`1234567890-=\\qüertyuiopöğasdfghjklıəzxcvbnmçş.',shift:{0:'~!"Ⅶ;%:?*()_+/',21:'İ',46:','},caps:{21:'İ'},shift_caps:{21:'i'}});
