﻿VirtualKeyboard.addLayout({code:'EN-US',name:'United States-Dvorak left',normal:'`[]/pfmlj4321\\;qbyurso.65=-kcdtheaz87\'xgvwni,09',shift:{0:'~{}?',9:'$#@!|:',22:'>^%+_',35:'*&"',44:'<)('}});
