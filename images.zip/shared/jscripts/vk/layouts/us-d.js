﻿VirtualKeyboard.addLayout({code:'EN-US',name:'United States-Dvorak',normal:'`1234567890[]\\\',.pyfgcrl/=aoeuidhtns-;qjkxbmwvz',shift:{0:'~!@#$%^&*(){}|"<>',24:'?+',36:'_:'}});
