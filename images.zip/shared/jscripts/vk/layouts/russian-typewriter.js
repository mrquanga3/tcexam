﻿VirtualKeyboard.addLayout({code:'RU',name:'Russian (Typewriter)',normal:'|№-/":,._?%!;)йцукенгшщзхъфывапролджэячсмитьбюё',shift:{0:'+1234567890=\\('}});
