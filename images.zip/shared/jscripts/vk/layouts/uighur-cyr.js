﻿VirtualKeyboard.addLayout({code:'UG',name:'Uighur Cyrillic',normal:'ёқңғүөҗәһ\'(-ъэяшертыуиопющасдфгчйкльжзхцвбнм,.;',shift:{9:'")_',44:'<>:'},caps:{9:'")'},shift_caps:{9:'\'('}});
