﻿VirtualKeyboard.addLayout({code:'LT',name:'Lithuanian IBM',normal:'`!"/;:,.?()_+|ąžertyuiopį“asdfghjklųėzūcvbnmčšę',shift:{0:'~1234567890-=\\',25:'”'},alt:{7:'{[]}',16:'€'}});
