﻿VirtualKeyboard.addLayout({code:'RU',name:'Russian',normal:'ё1234567890-=\\йцукенгшщзхъфывапролджэячсмитьбю.',shift:{1:'!"№;%:?*()_+/',46:','}});
