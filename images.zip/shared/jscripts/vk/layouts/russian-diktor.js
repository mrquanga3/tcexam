﻿VirtualKeyboard.addLayout({code:'RU',name:'Russian (Diktor)',normal:'ё1234567890*=\\цья,.звкдчшщуиеоалнтсрйфэхыюбмпгж',shift:{1:'ЪЬ№%:;-"()_+/',15:'ъ',17:'?!'}});
