﻿VirtualKeyboard.addLayout({code:'UZ',name:'Uzbek Cyrillic',normal:'ё1234567890ғҳ\\йцукенгшўзхъфқвапролджэячсмитьбю.',shift:{1:'!"№;%:?*()',13:'/',46:','}});
